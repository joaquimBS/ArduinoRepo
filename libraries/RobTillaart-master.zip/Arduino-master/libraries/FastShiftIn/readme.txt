
FastShiftIn is a class that speeds up the shifting by using predetermined posts and masks.
Its performance is about twice as fast as the normal Arduino shiftIn.

There is a thread on the forum here - http://forum.arduino.cc/index.php?topic=184002.0 - 
This thread also discusses a FastShiftOut