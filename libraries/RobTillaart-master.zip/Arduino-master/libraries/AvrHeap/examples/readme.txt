
2015-dec-12:
With version 0.1.04 AvrHeap() got a new interface.
The heapdemo1 is a 0.1.00 - 0.1.03 example for historical reasons.
The heapdemo2 is the demo to use for version 0.1.04 (and up).


 